# my-video

    npm install
    npm run dev                       # live preview in Remotion Studio
    npx remotion render TitleCard out/title-card.mp4

Edit the text in `src/Root.tsx` (defaultProps) or pass it at render time:

    npx remotion render TitleCard out/hi.mp4 --props='{"title":"Hello","subtitle":"World"}'
