import { Composition } from "remotion";
import { TitleCard, titleCardSchemaDefaults } from "./TitleCard";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="TitleCard"
      component={TitleCard}
      durationInFrames={150}
      fps={30}
      width={1920}
      height={1080}
      defaultProps={titleCardSchemaDefaults}
    />
  );
};
