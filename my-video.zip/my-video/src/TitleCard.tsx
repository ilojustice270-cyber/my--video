import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

export const titleCardSchemaDefaults = {
  title: "Made with code",
  subtitle: "A video rendered from React",
};

type Props = typeof titleCardSchemaDefaults;

const INK = "#14213d";
const PAPER = "#f2efe6";
const SIGNAL = "#2a9d8f";

export const TitleCard: React.FC<Props> = ({ title, subtitle }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();

  // Bar sweeps across first
  const bar = spring({ frame, fps, config: { damping: 200 }, durationInFrames: 30 });
  const barWidth = interpolate(bar, [0, 1], [0, 100]);

  // Title letters rise in one after another (the single orchestrated moment)
  const letters = title.split("");

  // Subtitle fades in after the title lands
  const subOpacity = interpolate(frame, [55, 80], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // Whole scene fades out at the end
  const fadeOut = interpolate(
    frame,
    [durationInFrames - 20, durationInFrames],
    [1, 0],
    { extrapolateLeft: "clamp" }
  );

  return (
    <AbsoluteFill
      style={{
        backgroundColor: PAPER,
        justifyContent: "center",
        padding: "0 160px",
        opacity: fadeOut,
        fontFamily: "Georgia, 'Times New Roman', serif",
      }}
    >
      <div
        style={{
          height: 14,
          width: `${barWidth}%`,
          maxWidth: 520,
          backgroundColor: SIGNAL,
          marginBottom: 48,
        }}
      />
      <div style={{ fontSize: 180, fontWeight: 700, color: INK, lineHeight: 1.05, display: "flex", flexWrap: "wrap" }}>
        {letters.map((ch, i) => {
          const s = spring({
            frame: frame - (20 + i * 2),
            fps,
            config: { damping: 14, stiffness: 120 },
          });
          return (
            <span
              key={i}
              style={{
                display: "inline-block",
                whiteSpace: "pre",
                transform: `translateY(${interpolate(s, [0, 1], [90, 0])}px)`,
                opacity: s,
              }}
            >
              {ch}
            </span>
          );
        })}
      </div>
      <div style={{ fontSize: 52, color: INK, opacity: subOpacity * 0.75, marginTop: 36 }}>
        {subtitle}
      </div>
    </AbsoluteFill>
  );
};
